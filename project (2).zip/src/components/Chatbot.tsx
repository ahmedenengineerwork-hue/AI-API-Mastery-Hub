import { useEffect, useRef, useState } from "react";
import { MessageCircle, Send, X, Sparkles, Loader2 } from "lucide-react";

// ⚠️ Replace the string below with your real Gemini API key before running locally.
// Get one at: https://aistudio.google.com/app/apikey
const GEMINI_API_KEY = "YOUR_REAL_API_KEY_HERE";
const GEMINI_MODEL = "gemini-2.5-pro";

const SYSTEM_PROMPT = `You are "API Assistant", an expert Developer Advocate for the Google Gemini API.
Your mission is to help developers obtain a Gemini API key and integrate it into their app.

ALWAYS follow these rules:
1. Whenever the user asks how to get an API key, give them the direct link:
   https://aistudio.google.com/app/apikey
   and walk them through: open the link → sign in with Google → click "Create API key" → copy & store it securely.
2. Early in the conversation, ask: "What programming language or framework are you using? (e.g., Python, Node.js, curl, etc.)"
3. Once they answer, give EXACT step-by-step instructions for THAT language:
   - install command (e.g. \`pip install -q -U google-generativeai\` for Python, \`npm install @google/generative-ai\` for Node.js)
   - a copy-pasteable starter snippet using the \`gemini-2.5-pro\` model
   - how to read the key from an environment variable
4. Always remind the user: never hardcode the API key in public/frontend code, never commit it to git, and rotate it if leaked.
5. Be concise, friendly, use Markdown, and format code in fenced code blocks with the language tag.
6. If the user asks about features unrelated to Gemini, gently steer them back to Gemini API onboarding.`;

type Msg = { role: "user" | "model"; text: string };

export function Chatbot() {
  const [open, setOpen] = useState(false);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [messages, setMessages] = useState<Msg[]>([
    { role: "model", text: "Hi! I'm your API Assistant. Ask me anything about getting your Gemini API key or building your first chatbot." },
  ]);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
  }, [messages, loading]);

  const callGemini = async (history: Msg[]): Promise<string> => {
    if (!GEMINI_API_KEY || GEMINI_API_KEY === "YOUR_REAL_API_KEY_HERE") {
      throw new Error(
        "No API key configured. Open src/components/Chatbot.tsx and replace YOUR_REAL_API_KEY_HERE with your Gemini API key."
      );
    }

    const url = `https://generativelanguage.googleapis.com/v1beta/models/${GEMINI_MODEL}:generateContent?key=${encodeURIComponent(
      GEMINI_API_KEY
    )}`;

    const body = {
      systemInstruction: { role: "system", parts: [{ text: SYSTEM_PROMPT }] },
      contents: history.map((m) => ({
        role: m.role === "user" ? "user" : "model",
        parts: [{ text: m.text }],
      })),
    };

    const res = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });

    if (!res.ok) {
      const errText = await res.text();
      if (res.status === 429) throw new Error("Rate limit exceeded (429). Free tier quota reached — wait and retry.");
      if (res.status === 400) throw new Error("Invalid request or API key (400). Double-check your key.");
      if (res.status === 403) throw new Error("Forbidden (403). Key may be restricted or the API not enabled for your region.");
      throw new Error(`Gemini API error ${res.status}: ${errText.slice(0, 200)}`);
    }

    const data = await res.json();
    const text =
      data?.candidates?.[0]?.content?.parts?.map((p: { text?: string }) => p.text).filter(Boolean).join("\n") ?? "";
    return text || "(empty response)";
  };

  const send = async () => {
    const text = input.trim();
    if (!text || loading) return;
    const next: Msg[] = [...messages, { role: "user", text }];
    setMessages(next);
    setInput("");
    setLoading(true);

    try {
      const reply = await callGemini(next);
      setMessages((m) => [...m, { role: "model", text: reply }]);
    } catch (e: unknown) {
      const msg = e instanceof Error ? e.message : "Unknown error";
      setMessages((m) => [...m, { role: "model", text: `⚠️ ${msg}` }]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      <button
        onClick={() => setOpen((o) => !o)}
        aria-label="Open API Assistant"
        className="fixed bottom-6 right-6 z-50 group flex items-center gap-2 rounded-full px-5 py-4 text-primary-foreground shadow-[var(--shadow-elegant)] transition-all hover:scale-105"
        style={{ background: "var(--gradient-hero)" }}
      >
        {open ? <X className="h-5 w-5" /> : <MessageCircle className="h-5 w-5" />}
        {!open && <Sparkles className="h-4 w-4 animate-pulse" />}
      </button>

      {open && (
        <div className="fixed bottom-24 right-6 z-50 flex h-[32rem] w-[22rem] max-w-[calc(100vw-2rem)] flex-col overflow-hidden rounded-2xl border border-border bg-card shadow-[var(--shadow-elegant)]">
          <div
            className="flex items-center gap-3 px-4 py-3 text-primary-foreground"
            style={{ background: "var(--gradient-hero)" }}
          >
            <div className="flex h-9 w-9 items-center justify-center rounded-full bg-white/20 backdrop-blur">
              <Sparkles className="h-5 w-5" />
            </div>
            <div>
              <div className="font-display text-base font-semibold">API Assistant</div>
              <div className="text-xs opacity-80">Powered by Gemini</div>
            </div>
          </div>

          <div ref={scrollRef} className="flex-1 space-y-3 overflow-y-auto bg-secondary/40 p-4">
            {messages.map((m, i) => (
              <div key={i} className={`flex ${m.role === "user" ? "justify-end" : "justify-start"}`}>
                <div
                  className={`max-w-[85%] whitespace-pre-wrap rounded-2xl px-3.5 py-2 text-sm leading-relaxed ${
                    m.role === "user"
                      ? "rounded-br-sm bg-primary text-primary-foreground"
                      : "rounded-bl-sm bg-card text-card-foreground border border-border"
                  }`}
                >
                  {m.text}
                </div>
              </div>
            ))}
            {loading && (
              <div className="flex justify-start">
                <div className="flex items-center gap-2 rounded-2xl rounded-bl-sm border border-border bg-card px-3.5 py-2 text-sm text-muted-foreground">
                  <Loader2 className="h-4 w-4 animate-spin" /> Thinking…
                </div>
              </div>
            )}
          </div>

          <form
            onSubmit={(e) => { e.preventDefault(); send(); }}
            className="flex items-center gap-2 border-t border-border bg-card p-3"
          >
            <input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Ask about Gemini API…"
              className="flex-1 rounded-full border border-input bg-background px-4 py-2 text-sm outline-none focus:ring-2 focus:ring-ring"
            />
            <button
              type="submit"
              disabled={loading || !input.trim()}
              className="flex h-10 w-10 items-center justify-center rounded-full text-primary-foreground transition-opacity disabled:opacity-50"
              style={{ background: "var(--gradient-hero)" }}
              aria-label="Send"
            >
              <Send className="h-4 w-4" />
            </button>
          </form>
        </div>
      )}
    </>
  );
}
