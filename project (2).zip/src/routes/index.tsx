import { createFileRoute } from "@tanstack/react-router";
import { Sparkles, Zap, Code2, Layers, ExternalLink, KeyRound, MousePointerClick, Copy, ShieldAlert, ArrowRight, Check, Globe, Eye, EyeOff, Loader2, PlayCircle, Calculator, HelpCircle } from "lucide-react";
import { useMemo, useState } from "react";
import { Chatbot } from "@/components/Chatbot";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Slider } from "@/components/ui/slider";

export const Route = createFileRoute("/")({
  component: Index,
  head: () => ({
    meta: [
      { title: "Master the Google Gemini API: Get Your Key in Minutes" },
      { name: "description", content: "Step-by-step guide for developers to get a Google Gemini API key, with code samples, a live API tester, cost calculator, and troubleshooting." },
      { property: "og:title", content: "Master the Google Gemini API" },
      { property: "og:description", content: "Step-by-step guide to obtain your Gemini API key and integrate AI into your apps." },
    ],
    links: [
      { rel: "preconnect", href: "https://fonts.googleapis.com" },
      { rel: "preconnect", href: "https://fonts.gstatic.com", crossOrigin: "anonymous" },
      { rel: "stylesheet", href: "https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Space+Grotesk:wght@500;600;700&family=JetBrains+Mono:wght@400;500&display=swap" },
    ],
  }),
});

const features = [
  { icon: Zap, title: "Powerful AI", desc: "A state-of-the-art multimodal model handling text, images, audio, and code with frontier reasoning." },
  { icon: Code2, title: "Easy Integration", desc: "Developer-friendly REST API and official SDKs for Python, Node.js, Go, and more — start in minutes." },
  { icon: Layers, title: "Versatile", desc: "Build chatbots, content generators, analyzers, agents, and creative tools across any domain." },
];

const steps = [
  { icon: ExternalLink, title: "Access Google AI Studio", body: "Go to Google AI Studio and sign in with your Google Account.", cta: { label: "Go to AI Studio", href: "https://aistudio.google.com/app/apikey" } },
  { icon: KeyRound, title: "Locate API Keys", body: "On the left sidebar, click on \"Get API key\" to open the API keys dashboard." },
  { icon: MousePointerClick, title: "Create the Key", body: "Click the \"Create API key\" button. You can create it in a new project or an existing Google Cloud project." },
  { icon: Copy, title: "Copy & Secure", body: "Copy your new API key.", warning: "Crucial: Keep it secret! Never expose it in public client-side code or commit it to a repository." },
];

const codeSamples: Record<string, { filename: string; code: string }> = {
  python: {
    filename: "main.py",
    code: `# pip install -q -U google-generativeai
import os
import google.generativeai as genai

genai.configure(api_key=os.environ["GEMINI_API_KEY"])

model = genai.GenerativeModel("gemini-2.5-pro")
response = model.generate_content("Explain how AI works in one sentence.")

print(response.text)`,
  },
  nodejs: {
    filename: "index.js",
    code: `// npm install @google/generative-ai
import { GoogleGenerativeAI } from "@google/generative-ai";

const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);
const model = genAI.getGenerativeModel({ model: "gemini-2.5-pro" });

const result = await model.generateContent("Explain how AI works in one sentence.");
console.log(result.response.text());`,
  },
  curl: {
    filename: "request.sh",
    code: `curl "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-pro:generateContent?key=$GEMINI_API_KEY" \\
  -H 'Content-Type: application/json' \\
  -X POST \\
  -d '{
    "contents": [{
      "parts": [{ "text": "Explain how AI works in one sentence." }]
    }]
  }'`,
  },
  go: {
    filename: "main.go",
    code: `// go get github.com/google/generative-ai-go/genai
package main

import (
	"context"
	"fmt"
	"os"

	"github.com/google/generative-ai-go/genai"
	"google.golang.org/api/option"
)

func main() {
	ctx := context.Background()
	client, err := genai.NewClient(ctx, option.WithAPIKey(os.Getenv("GEMINI_API_KEY")))
	if err != nil { panic(err) }
	defer client.Close()

	model := client.GenerativeModel("gemini-2.5-pro")
	resp, err := model.GenerateContent(ctx, genai.Text("Explain how AI works in one sentence."))
	if err != nil { panic(err) }
	fmt.Println(resp.Candidates[0].Content.Parts[0])
}`,
  },
  java: {
    filename: "Main.java",
    code: `// implementation 'com.google.cloud:google-cloud-vertexai:1.+'
import com.google.cloud.vertexai.VertexAI;
import com.google.cloud.vertexai.api.GenerateContentResponse;
import com.google.cloud.vertexai.generativeai.GenerativeModel;
import com.google.cloud.vertexai.generativeai.ResponseHandler;

public class Main {
  public static void main(String[] args) throws Exception {
    try (VertexAI vertexAi = new VertexAI("your-project-id", "us-central1")) {
      GenerativeModel model = new GenerativeModel("gemini-2.5-pro", vertexAi);
      GenerateContentResponse response = model.generateContent("Explain how AI works in one sentence.");
      System.out.println(ResponseHandler.getText(response));
    }
  }
}`,
  },
  cpp: {
    filename: "main.cpp",
    code: `// Using libcurl to call the REST API
#include <cstdlib>
#include <iostream>
#include <string>
#include <curl/curl.h>

int main() {
  const char* key = std::getenv("GEMINI_API_KEY");
  std::string url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-pro:generateContent?key=";
  url += key ? key : "";

  CURL* curl = curl_easy_init();
  struct curl_slist* headers = nullptr;
  headers = curl_slist_append(headers, "Content-Type: application/json");

  const char* body = R"({"contents":[{"parts":[{"text":"Explain how AI works in one sentence."}]}]})";

  curl_easy_setopt(curl, CURLOPT_URL, url.c_str());
  curl_easy_setopt(curl, CURLOPT_HTTPHEADER, headers);
  curl_easy_setopt(curl, CURLOPT_POSTFIELDS, body);
  curl_easy_perform(curl);
  curl_easy_cleanup(curl);
  return 0;
}`,
  },
};

const langTabs = [
  { id: "python", label: "Python" },
  { id: "nodejs", label: "Node.js" },
  { id: "curl", label: "cURL" },
  { id: "go", label: "Go" },
  { id: "java", label: "Java" },
  { id: "cpp", label: "C++" },
];

function CopyButton({ text }: { text: string }) {
  const [copied, setCopied] = useState(false);
  return (
    <button
      type="button"
      onClick={async () => {
        try {
          await navigator.clipboard.writeText(text);
          setCopied(true);
          setTimeout(() => setCopied(false), 1800);
        } catch {
          /* noop */
        }
      }}
      className="inline-flex items-center gap-1.5 rounded-md border border-white/15 bg-white/10 px-2.5 py-1 text-xs font-medium text-white/90 backdrop-blur transition hover:bg-white/20"
    >
      {copied ? <Check className="h-3.5 w-3.5" /> : <Copy className="h-3.5 w-3.5" />}
      {copied ? "Copied" : "Copy Code"}
    </button>
  );
}

function CodeBlock({ filename, code }: { filename: string; code: string }) {
  return (
    <div className="overflow-hidden rounded-2xl border border-border shadow-[var(--shadow-elegant)]">
      <div className="flex items-center gap-2 px-4 py-3" style={{ background: "var(--code-bg)" }}>
        <span className="h-3 w-3 rounded-full bg-[oklch(0.6_0.2_25)]" />
        <span className="h-3 w-3 rounded-full bg-[oklch(0.78_0.15_75)]" />
        <span className="h-3 w-3 rounded-full bg-[oklch(0.7_0.18_145)]" />
        <span className="ml-3 font-mono text-xs text-white/60">{filename}</span>
        <div className="ml-auto">
          <CopyButton text={code} />
        </div>
      </div>
      <pre className="overflow-x-auto p-6 text-sm leading-relaxed" style={{ background: "var(--code-bg)", color: "var(--code-fg)" }}>
        <code>{code}</code>
      </pre>
    </div>
  );
}

function ApiTester() {
  const [apiKey, setApiKey] = useState("");
  const [showKey, setShowKey] = useState(false);
  const [prompt, setPrompt] = useState("");
  const [loading, setLoading] = useState(false);
  const [response, setResponse] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const run = async () => {
    if (!apiKey.trim() || loading) return;
    setLoading(true);
    setError(null);
    setResponse(null);
    try {
      const res = await fetch(
        `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-pro:generateContent?key=${encodeURIComponent(apiKey.trim())}`,
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            contents: [{ parts: [{ text: prompt.trim() || "Explain quantum computing in one simple sentence" }] }],
          }),
        },
      );
      if (!res.ok) {
        let detail = "";
        try { const j = await res.json(); detail = j?.error?.message ?? ""; } catch { /* noop */ }
        if (res.status === 429) setError("Rate limit exceeded (429). The free tier limit was reached — wait 60 seconds, implement exponential backoff, or upgrade to pay-as-you-go.");
        else if (res.status === 400) setError(`Bad request (400). Your API key may be invalid or malformed. ${detail}`);
        else if (res.status === 403) setError(`Forbidden (403). Your key may lack access, or your region is not supported. ${detail}`);
        else setError(`Error ${res.status}. ${detail}`);
        return;
      }
      const json = await res.json();
      const text = json?.candidates?.[0]?.content?.parts?.map((p: { text?: string }) => p.text ?? "").join("") ?? "";
      setResponse(text || "(empty response)");
    } catch (e: unknown) {
      setError(e instanceof Error ? e.message : "Network error");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="rounded-2xl border border-border bg-card p-6 shadow-[var(--shadow-card)] md:p-8">
      <div className="space-y-5">
        <div>
          <label className="mb-2 block text-sm font-medium">Your Gemini API Key</label>
          <div className="relative">
            <input
              type={showKey ? "text" : "password"}
              value={apiKey}
              onChange={(e) => setApiKey(e.target.value)}
              placeholder="AIza..."
              className="w-full rounded-lg border border-input bg-background px-4 py-2.5 pr-12 font-mono text-sm outline-none focus:ring-2 focus:ring-ring"
            />
            <button
              type="button"
              onClick={() => setShowKey((s) => !s)}
              className="absolute right-2 top-1/2 -translate-y-1/2 rounded-md p-1.5 text-muted-foreground hover:bg-secondary hover:text-foreground"
              aria-label={showKey ? "Hide key" : "Show key"}
            >
              {showKey ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
            </button>
          </div>
          <p className="mt-1.5 text-xs text-muted-foreground">Processed locally in your browser. Never sent to our servers.</p>
        </div>

        <div>
          <label className="mb-2 block text-sm font-medium">Prompt</label>
          <textarea
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            placeholder="Explain quantum computing in one simple sentence"
            rows={3}
            className="w-full resize-none rounded-lg border border-input bg-background px-4 py-2.5 text-sm outline-none focus:ring-2 focus:ring-ring"
          />
        </div>

        <button
          onClick={run}
          disabled={loading || !apiKey.trim()}
          className="inline-flex items-center gap-2 rounded-full px-6 py-3 text-sm font-semibold text-primary-foreground shadow-[var(--shadow-elegant)] transition hover:scale-[1.02] disabled:cursor-not-allowed disabled:opacity-50"
          style={{ background: "var(--gradient-hero)" }}
        >
          {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <PlayCircle className="h-4 w-4" />}
          {loading ? "Testing…" : "Test API Key"}
        </button>

        {(response || error) && (
          <div className="mt-2 rounded-xl border border-border bg-secondary/40 p-5">
            <div className="mb-2 text-xs font-semibold uppercase tracking-wider text-muted-foreground">Live Response</div>
            {error ? (
              <p className="whitespace-pre-wrap text-sm text-destructive">{error}</p>
            ) : (
              <p className="whitespace-pre-wrap text-sm leading-relaxed">{response}</p>
            )}
          </div>
        )}
      </div>
    </div>
  );
}

function CostEstimator() {
  const [mau, setMau] = useState(1000);
  const [reqPerDay, setReqPerDay] = useState(10);
  const [tokens, setTokens] = useState(1000);

  const calc = useMemo(() => {
    const inputTokens = tokens * 0.6;
    const outputTokens = tokens * 0.4;
    const totalRequests = mau * reqPerDay * 30;
    const totalInput = totalRequests * inputTokens;
    const totalOutput = totalRequests * outputTokens;
    const inputCost = (totalInput / 1_000_000) * 1.25;
    const outputCost = (totalOutput / 1_000_000) * 5.0;
    const total = inputCost + outputCost;
    const inputPct = total > 0 ? (inputCost / total) * 100 : 0;
    return {
      totalTokens: totalInput + totalOutput,
      total,
      inputCost,
      outputCost,
      inputPct,
      outputPct: 100 - inputPct,
    };
  }, [mau, reqPerDay, tokens]);

  const fmt = (n: number) => n.toLocaleString(undefined, { maximumFractionDigits: 0 });
  const usd = (n: number) => `$${n.toLocaleString(undefined, { maximumFractionDigits: 2 })}`;

  return (
    <div className="grid gap-8 rounded-2xl border border-border bg-card p-6 shadow-[var(--shadow-card)] md:p-8 lg:grid-cols-2">
      <div className="space-y-7">
        <SliderRow label="Monthly Active Users" value={mau} suffix=" MAUs" min={100} max={100000} step={100} onChange={setMau} />
        <SliderRow label="API Requests per User / Day" value={reqPerDay} suffix=" req" min={1} max={100} step={1} onChange={setReqPerDay} />
        <SliderRow label="Avg Tokens per Request" value={tokens} suffix=" tokens" min={100} max={4000} step={50} onChange={setTokens} />
        <p className="text-xs text-muted-foreground">Assumes a 60/40 input/output split. Pricing: $1.25 / 1M input tokens, $5.00 / 1M output tokens (Gemini 2.5 Pro).</p>
      </div>

      <div className="space-y-5 rounded-xl bg-secondary/40 p-6">
        <div>
          <div className="text-xs font-medium uppercase tracking-wider text-muted-foreground">Estimated Monthly Cost</div>
          <div className="mt-1 font-display text-5xl font-bold bg-clip-text text-transparent" style={{ backgroundImage: "var(--gradient-hero)" }}>
            {usd(calc.total)}
          </div>
          <div className="mt-1 text-sm text-muted-foreground">{fmt(calc.totalTokens)} total tokens / month</div>
        </div>

        <div className="space-y-3 pt-2">
          <div>
            <div className="mb-1.5 flex justify-between text-xs">
              <span className="font-medium">Input tokens</span>
              <span className="text-muted-foreground">{usd(calc.inputCost)}</span>
            </div>
            <div className="h-2 overflow-hidden rounded-full bg-border">
              <div className="h-full rounded-full bg-primary transition-all" style={{ width: `${calc.inputPct}%` }} />
            </div>
          </div>
          <div>
            <div className="mb-1.5 flex justify-between text-xs">
              <span className="font-medium">Output tokens</span>
              <span className="text-muted-foreground">{usd(calc.outputCost)}</span>
            </div>
            <div className="h-2 overflow-hidden rounded-full bg-border">
              <div className="h-full rounded-full transition-all" style={{ width: `${calc.outputPct}%`, background: "var(--accent)" }} />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function SliderRow({ label, value, suffix, min, max, step, onChange }: { label: string; value: number; suffix: string; min: number; max: number; step: number; onChange: (v: number) => void }) {
  return (
    <div>
      <div className="mb-2 flex items-baseline justify-between">
        <label className="text-sm font-medium">{label}</label>
        <span className="font-mono text-sm font-semibold text-primary">{value.toLocaleString()}{suffix}</span>
      </div>
      <Slider value={[value]} min={min} max={max} step={step} onValueChange={(v) => onChange(v[0])} />
    </div>
  );
}

const faqs = [
  {
    q: "Error 429 — Too Many Requests",
    a: "You've hit the rate limit (usually the free tier's per-minute or daily cap). Fixes: (1) wait 60 seconds and retry, (2) implement exponential backoff in your client, (3) upgrade to pay-as-you-go in Google AI Studio for much higher quotas.",
  },
  {
    q: "Error 400 — API Key Not Found / Invalid",
    a: "Your key may be misspelled, contain extra whitespace, or hasn't fully propagated through Google's servers yet (can take ~1 minute after creation). Recreate the key in AI Studio and copy it carefully — never wrap it in quotes inside .env files.",
  },
  {
    q: "Error 403 — User Location Not Supported",
    a: "Gemini is blocked in certain regions. Workarounds: deploy your backend to a supported region (e.g. a US-based Cloud Run, Vercel, or Cloudflare Worker) and proxy requests through it, or use a VPN/cloud host situated in a supported region for local testing.",
  },
  {
    q: "How do I secure my key in production?",
    a: "Never embed your API key in a browser-based frontend — anyone can inspect the JS bundle and steal it. Always route requests through a secure backend server, serverless function, or edge function that reads the key from an environment variable. Also: rotate keys regularly, restrict them by referrer/IP in Google Cloud Console, and never commit them to Git.",
  },
];

function Index() {
  return (
    <div className="min-h-screen" style={{ background: "var(--gradient-soft)" }}>
      {/* Nav */}
      <header className="sticky top-0 z-40 border-b border-border/60 bg-background/80 backdrop-blur-lg">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-6 py-4">
          <div className="flex items-center gap-2 font-display font-semibold">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg text-primary-foreground" style={{ background: "var(--gradient-hero)" }}>
              <Sparkles className="h-4 w-4" />
            </div>
            Gemini Guide
          </div>
          <nav className="hidden gap-6 text-sm text-muted-foreground md:flex">
            <a href="#why" className="hover:text-foreground transition">Why Gemini</a>
            <a href="#guide" className="hover:text-foreground transition">Guide</a>
            <a href="#code" className="hover:text-foreground transition">Code</a>
            <a href="#tester" className="hover:text-foreground transition">Tester</a>
            <a href="#pricing" className="hover:text-foreground transition">Pricing</a>
            <a href="#faq" className="hover:text-foreground transition">FAQ</a>
          </nav>
          <a href="#guide" className="rounded-full bg-primary px-4 py-2 text-sm font-medium text-primary-foreground hover:opacity-90 transition">
            Start
          </a>
        </div>
      </header>

      {/* Hero */}
      <section className="relative overflow-hidden px-6 pt-20 pb-24 md:pt-32 md:pb-32">
        <div className="absolute inset-0 -z-10 opacity-30" style={{ background: "radial-gradient(60% 50% at 50% 0%, var(--primary-glow), transparent 70%)" }} />
        <div className="mx-auto max-w-4xl text-center">
          <div className="mb-6 inline-flex items-center gap-2 rounded-full border border-border bg-card/60 px-4 py-1.5 text-xs font-medium text-muted-foreground backdrop-blur">
            <Sparkles className="h-3.5 w-3.5 text-accent" />
            Developer guide — updated for Gemini 2.5
          </div>
          <h1 className="font-display text-5xl font-bold leading-[1.05] tracking-tight md:text-7xl">
            Master the Google Gemini API:{" "}
            <span className="bg-clip-text text-transparent" style={{ backgroundImage: "var(--gradient-hero)" }}>
              Get Your Key in Minutes.
            </span>
          </h1>
          <p className="mx-auto mt-6 max-w-2xl text-lg text-muted-foreground md:text-xl">
            A simple, step-by-step guide for developers to unlock the power of Google's AI models.
          </p>
          <div className="mt-10 flex flex-wrap items-center justify-center gap-4">
            <a
              href="#guide"
              className="group inline-flex items-center gap-2 rounded-full px-7 py-3.5 text-base font-semibold text-primary-foreground shadow-[var(--shadow-elegant)] transition-transform hover:scale-105"
              style={{ background: "var(--gradient-hero)" }}
            >
              Start the Guide
              <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
            </a>
            <a href="#tester" className="text-sm font-medium text-muted-foreground hover:text-foreground">
              Try the live tester →
            </a>
          </div>
        </div>
      </section>

      {/* Why Gemini */}
      <section id="why" className="px-6 py-24">
        <div className="mx-auto max-w-6xl">
          <div className="mb-14 text-center">
            <div className="text-sm font-medium text-accent">Why Gemini API</div>
            <h2 className="mt-2 font-display text-3xl font-bold md:text-4xl">Built for builders.</h2>
          </div>
          <div className="grid gap-6 md:grid-cols-3">
            {features.map((f) => (
              <div key={f.title} className="group rounded-2xl border border-border bg-card p-7 shadow-[var(--shadow-card)] transition-all hover:-translate-y-1">
                <div className="mb-5 flex h-12 w-12 items-center justify-center rounded-xl text-primary-foreground" style={{ background: "var(--gradient-hero)" }}>
                  <f.icon className="h-6 w-6" />
                </div>
                <h3 className="font-display text-xl font-semibold">{f.title}</h3>
                <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{f.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Step-by-Step Guide */}
      <section id="guide" className="px-6 py-24" style={{ background: "color-mix(in oklab, var(--primary) 4%, var(--background))" }}>
        <div className="mx-auto max-w-4xl">
          <div className="mb-14 text-center">
            <div className="text-sm font-medium text-accent">Step-by-Step</div>
            <h2 className="mt-2 font-display text-3xl font-bold md:text-4xl">From zero to API key in 4 steps.</h2>
          </div>

          <ol className="relative space-y-8 before:absolute before:left-[27px] before:top-2 before:bottom-2 before:w-px before:bg-border md:before:left-[31px]">
            {steps.map((s, i) => (
              <li key={i} className="relative flex gap-5 md:gap-7">
                <div className="relative z-10 flex h-14 w-14 shrink-0 items-center justify-center rounded-full border-4 border-background text-primary-foreground shadow-[var(--shadow-card)] md:h-16 md:w-16" style={{ background: "var(--gradient-hero)" }}>
                  <span className="font-display text-lg font-bold">{i + 1}</span>
                </div>
                <div className="flex-1 rounded-2xl border border-border bg-card p-6 shadow-[var(--shadow-card)]">
                  <div className="mb-2 flex items-center gap-2 text-accent">
                    <s.icon className="h-4 w-4" />
                    <span className="text-xs font-semibold uppercase tracking-wider">Step {i + 1}</span>
                  </div>
                  <h3 className="font-display text-xl font-semibold">{s.title}</h3>
                  <p className="mt-2 text-muted-foreground">{s.body}</p>
                  {s.cta && (
                    <a
                      href={s.cta.href}
                      target="_blank"
                      rel="noreferrer"
                      className="mt-4 inline-flex items-center gap-2 rounded-full bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition hover:opacity-90"
                    >
                      {s.cta.label} <ExternalLink className="h-3.5 w-3.5" />
                    </a>
                  )}
                  {s.warning && (
                    <div className="mt-4 flex items-start gap-3 rounded-xl border border-warning/40 bg-warning/15 p-4 text-warning-foreground">
                      <ShieldAlert className="mt-0.5 h-5 w-5 shrink-0 text-warning-foreground" />
                      <p className="text-sm font-medium">{s.warning}</p>
                    </div>
                  )}
                </div>
              </li>
            ))}
          </ol>
        </div>
      </section>

      {/* Quick Start Code Library — multi-language tabs */}
      <section id="code" className="px-6 py-24">
        <div className="mx-auto max-w-4xl">
          <div className="mb-10 text-center">
            <div className="inline-flex items-center gap-2 text-sm font-medium text-accent">
              <Code2 className="h-4 w-4" /> Quick Start Code Library
            </div>
            <h2 className="mt-2 font-display text-3xl font-bold md:text-4xl">Pick your language, copy, ship.</h2>
            <p className="mt-3 text-muted-foreground">
              Select your preferred language, copy the starter code, and insert your API key to bring Gemini 2.5 Pro into your application.
            </p>
          </div>

          <Tabs defaultValue="python" className="w-full">
            <TabsList className="mb-5 flex h-auto w-full flex-wrap justify-center gap-1 bg-secondary/60 p-1.5">
              {langTabs.map((t) => (
                <TabsTrigger key={t.id} value={t.id} className="rounded-full px-4 py-1.5 text-sm">
                  {t.label}
                </TabsTrigger>
              ))}
            </TabsList>
            {langTabs.map((t) => (
              <TabsContent key={t.id} value={t.id} className="mt-0">
                <CodeBlock filename={codeSamples[t.id].filename} code={codeSamples[t.id].code} />
              </TabsContent>
            ))}
          </Tabs>
        </div>
      </section>

      {/* Interactive API Tester */}
      <section id="tester" className="px-6 py-24" style={{ background: "color-mix(in oklab, var(--primary) 4%, var(--background))" }}>
        <div className="mx-auto max-w-3xl">
          <div className="mb-10 text-center">
            <div className="inline-flex items-center gap-2 text-sm font-medium text-accent">
              <PlayCircle className="h-4 w-4" /> Interactive API Tester
            </div>
            <h2 className="mt-2 font-display text-3xl font-bold md:text-4xl">Test your key instantly.</h2>
            <p className="mt-3 text-muted-foreground">
              Paste your freshly created Gemini API key and a prompt to see a live response from <code className="font-mono text-sm">gemini-2.5-pro</code>. Your key is processed entirely in your browser and never sent to our servers.
            </p>
          </div>
          <ApiTester />
        </div>
      </section>

      {/* Cost Estimator */}
      <section id="pricing" className="px-6 py-24">
        <div className="mx-auto max-w-5xl">
          <div className="mb-10 text-center">
            <div className="inline-flex items-center gap-2 text-sm font-medium text-accent">
              <Calculator className="h-4 w-4" /> Gemini Pricing &amp; Token Estimator
            </div>
            <h2 className="mt-2 font-display text-3xl font-bold md:text-4xl">Estimate your monthly cost.</h2>
            <p className="mt-3 text-muted-foreground">Drag the sliders to model your usage on Gemini 2.5 Pro.</p>
          </div>
          <CostEstimator />
        </div>
      </section>

      {/* Embed Gemini */}
      <section id="embed" className="px-6 py-24" style={{ background: "color-mix(in oklab, var(--primary) 4%, var(--background))" }}>
        <div className="mx-auto max-w-4xl">
          <div className="mb-10 text-center">
            <div className="inline-flex items-center gap-2 text-sm font-medium text-accent">
              <Globe className="h-4 w-4" /> Web Integration
            </div>
            <h2 className="mt-2 font-display text-3xl font-bold md:text-4xl">Embed Gemini in your website.</h2>
            <p className="mt-3 text-muted-foreground">
              Copy this starter snippet to add Gemini text generation to a plain HTML/JS project.
            </p>
          </div>

          <CodeBlock
            filename="index.html"
            code={`<script type="module">
  import { GoogleGenerativeAI } from "https://esm.run/@google/generative-ai";

  // Replace with your actual API key!
  const API_KEY = "YOUR_API_KEY_HERE";
  const genAI = new GoogleGenerativeAI(API_KEY);

  async function run() {
    const model = genAI.getGenerativeModel({ model: "gemini-2.5-pro" });
    const result = await model.generateContent("Explain the magic of AI in one sentence.");
    console.log((await result.response).text());
  }

  run();
</script>`}
          />
        </div>
      </section>

      {/* Troubleshooting FAQ */}
      <section id="faq" className="px-6 py-24">
        <div className="mx-auto max-w-3xl">
          <div className="mb-10 text-center">
            <div className="inline-flex items-center gap-2 text-sm font-medium text-accent">
              <HelpCircle className="h-4 w-4" /> Developer Troubleshooting
            </div>
            <h2 className="mt-2 font-display text-3xl font-bold md:text-4xl">Common error codes, fixed.</h2>
            <p className="mt-3 text-muted-foreground">The most common roadblocks when integrating Gemini — and exactly how to resolve them.</p>
          </div>

          <Accordion type="single" collapsible className="rounded-2xl border border-border bg-card p-2 shadow-[var(--shadow-card)]">
            {faqs.map((f, i) => (
              <AccordionItem key={i} value={`faq-${i}`} className="border-b border-border last:border-b-0">
                <AccordionTrigger className="px-4 text-left font-display text-base font-semibold hover:no-underline">
                  {f.q}
                </AccordionTrigger>
                <AccordionContent className="px-4 text-sm leading-relaxed text-muted-foreground">
                  {f.a}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border px-6 py-10 text-center text-sm text-muted-foreground">
        Created for educational purposes. Not officially affiliated with Google.
      </footer>

      <Chatbot />
    </div>
  );
}
