import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

const SYSTEM_PROMPT = `You are "API Assistant", an expert Developer Advocate for the Google Gemini API on this educational website.

ALWAYS follow these rules in every conversation:
1. Whenever a user asks how to get an API key, give them the direct link: https://aistudio.google.com/app/apikey
2. If you don't yet know the user's stack, ASK: "What programming language or framework are you using? (e.g., Python, Node.js, curl, etc.)"
3. Once they tell you the language/framework, give EXACT step-by-step instructions tailored to it, including:
   - The install command (e.g. \`pip install -q -U google-generativeai\` for Python, \`npm install @google/generative-ai\` for Node.js, raw \`curl\` examples, etc.)
   - A complete, copy-pasteable starter snippet using the \`gemini-2.5-pro\` model
   - How to read the API key from an environment variable (never hardcoded)
4. ALWAYS remind the user to keep their API key secret and never hardcode it in public frontend files or commit it to a repo.
5. Point users to the relevant sections of this page when useful: Hero, Why Gemini, Step-by-Step Guide (Steps 1–4), Embed Gemini in Your Website, and the Code Example.

Keep answers concise, friendly, and developer-focused. Prefer short, well-formatted code blocks.`;

const MessageSchema = z.object({
  role: z.enum(["user", "model"]),
  text: z.string().min(1).max(4000),
});

const InputSchema = z.object({
  messages: z.array(MessageSchema).min(1).max(50),
});

export const chatWithGemini = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) => InputSchema.parse(input))
  .handler(async ({ data }) => {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      return { reply: "", error: "Server is missing GEMINI_API_KEY." };
    }

    const contents = data.messages.map((m) => ({
      role: m.role,
      parts: [{ text: m.text }],
    }));

    try {
      const res = await fetch(
        `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-pro:generateContent?key=${apiKey}`,
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            system_instruction: { parts: [{ text: SYSTEM_PROMPT }] },
            contents,
          }),
        },
      );
      if (!res.ok) {
        const txt = await res.text();
        console.error("Gemini API error:", res.status, txt);
        return { reply: "", error: `Gemini API error (${res.status}).` };
      }
      const json = await res.json();
      const reply =
        json?.candidates?.[0]?.content?.parts
          ?.map((p: { text?: string }) => p.text ?? "")
          .join("") ?? "";
      return { reply: reply || "Sorry, no response.", error: null };
    } catch (err) {
      console.error("Gemini request failed:", err);
      return { reply: "", error: "Failed to reach Gemini." };
    }
  });
